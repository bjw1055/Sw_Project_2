import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import Login from "./components/Login";
import ProjectSelector from "./components/ProjectSelector";
import Dashboard from "./components/Dashboard";
import "./App.css";
import axios from "axios";

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(() => !!localStorage.getItem('token'));
  const [user, setUser] = useState(() => {
    const userStr = localStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
  });
  const [selectedProject, setSelectedProject] = useState(null);
  const [params] = useSearchParams();

  useEffect(() => {
    document.body.classList.toggle("dark", localStorage.getItem("theme") === "dark");

    const projectId = params.get("projectId");

    if (projectId) {
        const fetchProject = async () => {
          try {
            const res = await axios.get(`http://localhost:5000/api/projects/${projectId}`, {
                headers: {
                Authorization: `Bearer ${localStorage.getItem("token")}`,
              },
            });
            setSelectedProject(res.data);
          } catch (err) {
            console.error("프로젝트 로드 실패:", err);
          }
        };
        fetchProject();
      }
    }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setIsLoggedIn(false);
    setUser(null);
    setSelectedProject(null);
  };

  if (!isLoggedIn) {
    return <Login onLogin={(userData) => {
      setIsLoggedIn(true);
      setUser(userData);
    }} />;
  }

  return (
    <div className="app-container">
      {!selectedProject ? (
        <ProjectSelector
          user={user}
          onLogout={handleLogout}
          onSelect={(project) => {
            setSelectedProject(project);
          }}
        />
      ) : (
        <Dashboard
          user={user}
          onLogout={handleLogout}
          project={selectedProject}
          onBack={() => setSelectedProject(null)}
        />
      )}
    </div>
  );
}
