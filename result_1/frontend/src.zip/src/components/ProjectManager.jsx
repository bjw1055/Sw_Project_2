import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function ProjectManager({ onSelect }) {
  const [title, setTitle] = useState('');
  const [projects, setProjects] = useState([]);

  const token = localStorage.getItem('token');

  const fetchProjects = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/projects', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setProjects(res.data);
    } catch (err) {
      console.error('프로젝트 조회 실패:', err);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  const handleCreate = async () => {
    if (!title.trim()) return alert('제목을 입력하세요.');

    try {
      const res = await axios.post(
        'http://localhost:5000/api/projects',
        { title },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      const newProject = { id: res.data.id, title };
      setProjects((prev) => [...prev, newProject]); // 목록에 추가
      onSelect(newProject); // 방금 생성한 항목을 바로 선택
      setTitle('');
    } catch (err) {
      console.error('항목 생성 실패:', err);
    }
  };

  return (
    <div className="p-4 bg-white shadow rounded mb-6">
      <h3 className="font-semibold mb-2">📌 분석 항목 관리</h3>
      <div className="flex gap-2 mb-4">
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="새 항목 제목"
          className="border px-2 py-1 rounded flex-grow"
        />
        <button onClick={handleCreate} className="bg-blue-600 text-white px-3 rounded">
          생성
        </button>
      </div>

      {projects.length === 0 ? (
        <p className="text-sm text-gray-500">생성된 항목이 없습니다.</p>
      ) : (
        <ul className="space-y-1 text-sm">
          {projects.map((proj) => (
            <li key={proj.id}>
              <button onClick={() => onSelect(proj)} className="text-left hover:underline">
                📂 {proj.title}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
