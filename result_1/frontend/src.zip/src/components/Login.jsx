import React, { useState } from 'react';
import axios from 'axios';

export default function Login({ onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false); // 로그인/회원가입 모드 전환
  const [signupSuccess, setSignupSuccess] = useState(false);

  const handleAuth = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    const endpoint = isSignUp ? '/api/auth/register' : '/api/auth/login';

    try {
      const response = await axios.post(`http://localhost:5000${endpoint}`, {
        email,
        password,
      });

      const { token, user } = response.data;
      if (isSignUp) {
        alert('회원가입이 완료되었습니다!');
        setIsSignUp(false); // 로그인 화면으로 전환
        setEmail('');
        setPassword('');
        return; // 로그인은 아직 안 시도함
      }

      localStorage.setItem('token', token);
      localStorage.setItem('user', JSON.stringify(user));
      onLogin(user);
    } catch (err) {
      console.error('인증 실패:', err);
      setError(
        isSignUp
          ? '이미 존재하는 계정입니다.'
          : '이메일 또는 비밀번호가 올바르지 않습니다.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-wrapper">
      <img src="/assets/logo.png" alt="logo" className="login-logo" />
      <hr className="logo-divider" />
      <p className="login-desc">
        {isSignUp
          ? '서비스 이용을 위해 회원가입을 진행해주세요.'
          : '로그인 후 서비스를 이용할 수 있습니다.'}
      </p>

      <form onSubmit={handleAuth} className="login-form">
        <input
          type="email"
          placeholder="email"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
            setError('');
          }}
          required
        />
        <input
          type="password"
          placeholder="password"
          value={password}
          onChange={(e) => {
            setPassword(e.target.value);
            setError('');
          }}
          required
        />
        <button type="submit" disabled={loading}>
          {loading ? '처리 중...' : isSignUp ? '회원가입' : '로그인'}
        </button>
      </form>

      {signupSuccess && (
        <p className="login-success">
          회원가입이 완료되었습니다!
        </p>
      )}

      {error && <p className="login-error">{error}</p>}

      <p className="login-subtext">
        {isSignUp ? (
          <>
            이미 계정이 있으신가요?{' '}
            <button onClick={() => setIsSignUp(false)} className="link-button">
              로그인
            </button>
          </>
        ) : (
          <>
            아직 회원이 아니신가요?{' '}
            <button onClick={() => setIsSignUp(true)} className="link-button">
              회원가입
            </button>
          </>
        )}
      </p>
    </div>
  );
}
