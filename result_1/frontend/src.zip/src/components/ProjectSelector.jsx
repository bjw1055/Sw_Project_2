// ✅ ProjectSelector.jsx (기존 항목 리스트 + 새 보고서 추가 기능 포함)
import React, { useEffect, useState } from "react";
import axios from "axios";

export default function ProjectSelector({ user, onLogout }) {
  const [projects, setProjects] = useState([]);
  const [sortOption, setSortOption] = useState("created_desc");
  const [showModal, setShowModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [targetProjectToDelete, setTargetProjectToDelete] = useState(null);
  const [isCreating, setIsCreating] = useState(false);



  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const res = await axios.get("http://localhost:5000/api/projects", {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        setProjects(res.data);
      } catch (err) {
        console.error("프로젝트 목록 불러오기 실패", err);
      }
    };
  
    fetchProjects(); // ✅ 최초 1회 실행
  
    const handleStorageChange = (event) => {
      if (["projectCreated", "projectDeleted"].includes(event.key)) {
        console.log("📡 프로젝트 변경 감지됨 → 목록 재조회");
        fetchProjects();
      }
    };
  
    const handleVisibilityChange = () => {
      if (document.visibilityState === "visible") {
        const lastUpdate = Math.max(
          parseInt(localStorage.getItem("projectCreated") || 0),
          parseInt(localStorage.getItem("projectDeleted") || 0)
        );
        if (lastUpdate > 0) {
          console.log("👁️ 탭 재포커싱 감지 → 목록 재조회");
          fetchProjects();
        }
      }
    };
  
    window.addEventListener("storage", handleStorageChange);
    document.addEventListener("visibilitychange", handleVisibilityChange);
  
    return () => {
      window.removeEventListener("storage", handleStorageChange);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }, []);  

  const handleCreateProject = async () => {
    if (isCreating || !newTitle.trim()) return;
    setIsCreating(true);
  
    try {
      const res = await axios.post(
        "http://localhost:5000/api/projects",
        { title: newTitle },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      const projectId = res.data.id;
      window.open(`/?projectId=${projectId}`, "_blank");
      localStorage.setItem("projectCreated", Date.now());
      setShowModal(false);  
      setNewTitle('');      
    } catch (err) {
      console.error("새 프로젝트 생성 실패", err);
    } finally {
      setIsCreating(false);
    }
  };  

  const handleProjectClick = (proj) => {
    const projectId = proj.id;
    window.open(`/?projectId=${projectId}`, "_blank");
  };

  const handleDeleteProject = async () => {
    if (!targetProjectToDelete) return;
  
    try {
      await axios.delete(`http://localhost:5000/api/projects/${targetProjectToDelete}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      setProjects((prev) => prev.filter((p) => p.id !== targetProjectToDelete));
      localStorage.setItem("projectDeleted", Date.now());
    } catch (err) {
      console.error("프로젝트 삭제 실패", err);
    } finally {
      setTargetProjectToDelete(null);
      setShowDeleteModal(false);
    }
  };  

  const sortedProjects = [...projects].sort((a, b) => {
    if (sortOption === "title_asc") {
      return a.title.localeCompare(b.title);
    } else if (sortOption === "title_desc") {
      return b.title.localeCompare(a.title);
    } else if (sortOption === "created_asc") {
      return new Date(a.created_at) - new Date(b.created_at);
    } else {
      return new Date(b.created_at) - new Date(a.created_at);
    }
  });  

  return (
    <div id="root">
      <div className="app-container">
        <header className="header">
          <div className="header-left"></div>
            <img src="/assets/logo.png" alt="logo" className="logo-img" />
          <div className="header-right">
            <span className="user-email">{user?.email}</span>
            <button onClick={onLogout} className="logout-button">로그아웃</button>
          </div>
        </header>
  
        <main className="main-content">
          <div className="project-header-row">
            <button
                className="create-button"
                onClick={() => setShowModal(true)}
            >
                + 새 보고서 추가
            </button>
            <div className="sort-options">
                <label className="sort-label">Sorted By</label>
                <select
                    className="custom-select"
                    value={sortOption}
                    onChange={(e) => setSortOption(e.target.value)}
                >
                    <option value="title_desc">이름 (내림차순)</option>
                    <option value="title_asc">이름 (오름차순)</option>
                    <option value="created_desc">생성일 (내림차순)</option>
                    <option value="created_asc">생성일 (오름차순)</option>
                </select>
            </div>
          </div>
          <div className="report-list">
            {sortedProjects.map((proj) => (
                <div
                key={proj.id}
                className="report-card"
                onClick={() => handleProjectClick(proj)}
                >
                <div className="report-info">
                    <h3 className="report-title">{proj.title}</h3>
                    <p className="report-date">생성일: {new Date(proj.created_at).toLocaleDateString()}</p>
                </div>
                <button
                    className="report-delete"
                    onClick={(e) => {
                    e.stopPropagation();
                    setTargetProjectToDelete(proj.id);
                    setShowDeleteModal(true);
                    }}
                >
                    삭제
                </button>
                </div>
            ))}
          </div>
        </main>
        {showModal && (
          <div className="modal-overlay">
            <div className="modal-box">
              <h3>새 보고서 제목을 입력하세요</h3>
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="예: 2024년 상반기 매출 분석"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    handleCreateProject();
                  }
                }}
              />
              <div className="modal-buttons">
                <button onClick={handleCreateProject}>생성</button>
                <button onClick={() => setShowModal(false)}>취소</button>
              </div>
            </div>
          </div>
        )}
        {showDeleteModal && (
          <div className="modal-overlay">
            <div className="modal-box">
              <h3>보고서를 삭제하시겠습니까?</h3>
              <p>이 작업은 되돌릴 수 없습니다.</p>
              <div className="modal-buttons">
                <button onClick={handleDeleteProject}>삭제</button>
                <button onClick={() => setShowDeleteModal(false)}>취소</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );  
}
