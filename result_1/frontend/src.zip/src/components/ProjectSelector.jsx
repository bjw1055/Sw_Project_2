// ✅ ProjectSelector.jsx (기존 항목 리스트 + 새 보고서 추가 기능 포함)
import React, { useEffect, useState } from "react";
import axios from "axios";

export default function ProjectSelector({ user, onLogout }) {
  const [projects, setProjects] = useState([]);
  const [sortOption, setSortOption] = useState("created_desc");

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const res = await axios.get("http://localhost:5000/api/projects", {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        setProjects(res.data);
      } catch (err) {
        console.error("프로젝트 목록 불러오기 실패", err);
      }
    };
    fetchProjects();
  }, []);

  const handleCreateProject = async () => {
    const title = prompt("새 보고서 제목을 입력해주세요:");
    if (!title) return;

    try {
      const res = await axios.post(
        "http://localhost:5000/api/projects",
        { title },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      const projectId = res.data.id;
      window.open(`/?projectId=${projectId}`, "_blank");
    } catch (err) {
      console.error("새 프로젝트 생성 실패", err);
    }
  };

  const handleProjectClick = (proj) => {
    const projectId = proj.id;
    window.open(`/?projectId=${projectId}`, "_blank");
  };

  const handleDeleteProject = async (projId) => {
    const confirmDelete = window.confirm("정말 이 보고서를 삭제하시겠습니까?");
    if (!confirmDelete) return;

    try {
      await axios.delete(`http://localhost:5000/api/projects/${projId}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      setProjects((prev) => prev.filter((p) => p.id !== projId));
    } catch (err) {
      console.error("프로젝트 삭제 실패", err);
    }
  };

  const sortedProjects = [...projects].sort((a, b) => {
    if (sortOption === "title_asc") {
      return a.title.localeCompare(b.title);
    } else if (sortOption === "title_desc") {
      return b.title.localeCompare(a.title);
    } else if (sortOption === "created_asc") {
      return new Date(a.created_at) - new Date(b.created_at);
    } else {
      return new Date(b.created_at) - new Date(a.created_at);
    }
  });  

  return (
    <div id="root">
      <div className="app-container">
        <header className="header">
          <div className="header-left"></div>
            <img src="/assets/logo.png" alt="logo" className="logo-img" />
          <div className="header-right">
            <span className="user-email">{user?.email}</span>
            <button onClick={onLogout} className="logout-button">로그아웃</button>
          </div>
        </header>
  
        <main className="main-content">
          <div className="project-header-row">
            <button
                className="create-button"
                onClick={handleCreateProject}
            >
                ➕ 새 보고서 추가
            </button>
            <div className="sort-options">
                <label className="sort-label">Sorted By</label>
                <select
                    className="custom-select"
                    value={sortOption}
                    onChange={(e) => setSortOption(e.target.value)}
                >
                    <option value="title_desc">이름 (내림차순)</option>
                    <option value="title_asc">이름 (오름차순)</option>
                    <option value="created_desc">생성일 (내림차순)</option>
                    <option value="created_asc">생성일 (오름차순)</option>
                </select>
            </div>
          </div>
          <div className="report-list">
            {sortedProjects.map((proj) => (
                <div
                key={proj.id}
                className="report-card"
                onClick={() => handleProjectClick(proj)}
                >
                <div className="report-info">
                    <h3 className="report-title">{proj.title}</h3>
                    <p className="report-date">생성일: {new Date(proj.created_at).toLocaleDateString()}</p>
                </div>
                <button
                    className="report-delete"
                    onClick={(e) => {
                    e.stopPropagation();
                    handleDeleteProject(proj.id);
                    }}
                >
                    삭제
                </button>
                </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  );  
}
