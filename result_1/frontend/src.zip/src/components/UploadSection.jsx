import React, { useState } from "react";
import axios from "axios";
import { fetchExchangeRate, columnKeywords, guessColumn } from "./utils";

export default function UploadSection({ selectedProject, setAiResult, onUploadSuccess }) {
  const [files, setFiles] = useState([]);
  const [uploadError, setUploadError] = useState("");

  const handleFileChange = (e) => {
    const selectedFiles = Array.from(e.target.files);
    setFiles(selectedFiles);
    setUploadError("");
  };

  const handleUpload = async () => {
    if (!files || files.length === 0) {
      alert("업로드할 파일을 선택해주세요.");
      return;
    }

    const invalidFile = files.find(
      (f) => !f.name.endsWith(".csv") && !f.name.endsWith(".xlsx")
    );
    if (invalidFile) {
      alert("CSV 또는 Excel 파일만 업로드 가능합니다.");
      return;
    }

    if (!selectedProject) {
      alert("🔍 분석 항목을 먼저 선택해주세요.");
      return;
    }

    const formData = new FormData();
    files.forEach((file) => formData.append("files", file));
    formData.append("projectId", selectedProject.id);

    try {
      await axios.post("http://localhost:5000/api/upload", formData, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });

      const rate = await fetchExchangeRate();
      console.log("📈 환율:", rate);

      const res = await axios.get(
        `http://localhost:5000/api/products?projectId=${selectedProject.id}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );

      const adjustedData = res.data.map((row) => {
        const raw = row.raw_data || {};
        const keys = Object.keys(raw);
        const currencyKey = guessColumn(keys, columnKeywords.currency);
        const amountKey = guessColumn(keys, columnKeywords.amount);
        const currency = raw[currencyKey];

        if (currency === "USD" && amountKey && !isNaN(parseFloat(raw[amountKey]))) {
          raw[amountKey] = parseFloat(raw[amountKey]) * rate;
        }
        
        return { ...row, raw_data: raw };
      });
      
      onUploadSuccess(adjustedData);
      console.log("💸 조정된 환율 데이터:", adjustedData);
      setFiles([]);

      const predictRes = await axios.post(
        "http://localhost:5000/api/predict",
        { projectId: selectedProject.id },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      setAiResult(predictRes.data);
    } catch (err) {
      console.error("업로드 또는 예측 실패:", err);
      setUploadError("파일 업로드 중 오류가 발생했습니다.");
    }
  };

  return (
    <div className="upload-section">
      <p className="upload-description">분석할 CSV 또는 Excel 파일을 선택하세요</p>
      <div className="upload-center">
        <div className="button-row">
          <label htmlFor="fileUpload" className="file-upload-button">
            파일 선택
          </label>
          <input
            id="fileUpload"
            type="file"
            multiple
            onChange={handleFileChange}
            className="file-hidden-input"
          />

          {/* ✅ 업로드 버튼 오른쪽 배치 + 동일한 스타일 적용 */}
          <button
            onClick={handleUpload}
            disabled={files.length === 0 || !selectedProject}
            className="file-upload-button"
          >
            파일 업로드
          </button>
        </div>
      </div>

      {files.length > 0 && (
        <ul className="text-sm text-gray-500 mt-2">
          {files.map((f, i) => (
            <li key={i}>📄 {f.name}</li>
          ))}
        </ul>
      )}
      {uploadError && <div className="text-red-500 mt-1">{uploadError}</div>}
    </div>
  );
}
