import React, { useState, useEffect } from "react";
import axios from "axios";

export default function UploadSection({
  selectedProject,
  onUploadSuccess,
  uploadedFileNames = [],
}) {
  const [files, setFiles] = useState([]);
  const [uploadError, setUploadError] = useState("");
  const [uploadedFiles, setUploadedFiles] = useState(uploadedFileNames);

  useEffect(() => {
    setUploadedFiles(uploadedFileNames);
  }, [uploadedFileNames]);

  const handleFileChange = (e) => {
    const selectedFiles = Array.from(e.target.files);
    setFiles(selectedFiles);
    setUploadError("");
  };

  const handleUpload = async () => {
    if (!files.length) {
      alert("업로드할 파일을 선택해주세요.");
      return;
    }

    const invalidFile = files.find(
      (f) => !f.name.endsWith(".csv") && !f.name.endsWith(".xlsx")
    );
    if (invalidFile) {
      alert("CSV 또는 Excel 파일만 업로드 가능합니다.");
      return;
    }

    if (!selectedProject) {
      alert("🔍 분석 항목을 먼저 선택해주세요.");
      return;
    }

    const formData = new FormData();
    files.forEach((file) => formData.append("files", file));
    formData.append("projectId", selectedProject.id);

    try {
      await axios.post("http://localhost:5000/api/upload", formData, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });

      const res = await axios.get(
        `http://localhost:5000/api/products?projectId=${selectedProject.id}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );

      console.log("🐣 업로드 후 DB에서 불러온 원본 데이터:", res.data);
      onUploadSuccess(res.data); // ✅ 환율 및 예측은 Dashboard에서 처리

      const filenames = [...new Set(res.data.map((row) => row.filename).filter(Boolean))];
      setUploadedFiles(filenames);
      setFiles([]);
    } catch (err) {
      console.error("업로드 또는 불러오기 실패:", err?.response?.data || err);
      setUploadError("파일 업로드 중 오류가 발생했습니다.");
    }
  };

  return (
    <div className="upload-section">
      <p className="upload-description">분석할 CSV 또는 Excel 파일을 선택하세요</p>
      <div className="upload-center">
        <div className="button-row">
          <label htmlFor="fileUpload" className="file-upload-button">
            파일 선택
          </label>
          <input
            id="fileUpload"
            type="file"
            multiple
            onChange={handleFileChange}
            className="file-hidden-input"
          />
          <button
            onClick={handleUpload}
            disabled={files.length === 0 || !selectedProject}
            className="file-upload-button"
          >
            파일 업로드
          </button>
        </div>
      </div>

      {uploadedFiles.length > 0 && (
        <div className="uploaded-file-list">
          <strong className="uploaded-file-title">업로드한 파일</strong>
          <ul className="uploaded-file-ul">
            {uploadedFiles.map((name, idx) => (
              <li key={idx}>📄 {name}</li>
            ))}
          </ul>
        </div>
      )}

      {files.length > 0 && (
        <div>
          <p className="select-file-title">선택한 파일</p>
          <ul className="uploaded-file-ul">
            {files.map((f, i) => (
              <li key={i}>📥 {f.name}</li>
            ))}
          </ul>
        </div>
      )}

      {uploadError && <div className="text-red-500 mt-1">{uploadError}</div>}
    </div>
  );
}
