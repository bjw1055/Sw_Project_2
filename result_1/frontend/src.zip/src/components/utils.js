import axios from "axios";

export function guessColumn(columns, options) {
    for (const col of columns) {
      for (const opt of options) {
        if (new RegExp(opt, "i").test(col)) {
          return col;
        }
      }
    }
    return null;
  }

export function getMajorityColumn(data, columnOptions) {
    const countMap = {};
  
    data.forEach(row => {
      const keys = Object.keys(row.raw_data || {});
      keys.forEach(key => {
        for (const opt of columnOptions) {
          if (new RegExp(opt, "i").test(key)) {
            countMap[key] = (countMap[key] || 0) + 1;
          }
        }
      });
    });
  
    const sorted = Object.entries(countMap).sort((a, b) => b[1] - a[1]);
    return sorted.length > 0 ? sorted[0][0] : null;
  }
  
export function getValueByFallback(row, primaryKey, fallbackOptions = []) {
    if (!row) return "-";
    if (primaryKey in row) return row[primaryKey];
  
    for (const key of Object.keys(row)) {
      for (const opt of fallbackOptions) {
        if (new RegExp(opt, "i").test(key)) {
          return row[key];
        }
      }
    }
  
    return "-";
  }

  export function parseExcelDate(value) {
    if (typeof value === "number" && value > 20000 && value < 50000) {
      const base = new Date(Date.UTC(1899, 11, 30));
      const corrected = new Date(base.getTime() + value * 86400000);
      return corrected.toISOString().substring(0, 10);
    }
  
    if (typeof value === "string" && /^\d{4}\.\d{1,2}\.\d{1,2}$/.test(value)) {
      const [year, month, day] = value.split(".").map((v) => parseInt(v));
      const corrected = new Date(Date.UTC(year, month - 1, day));
      return corrected.toISOString().substring(0, 10);
    }
  
    const d = new Date(value);
    return !isNaN(d.getTime()) ? d.toISOString().substring(0, 10) : "날짜 없음";
  }
  
  
  
  
  
  export const columnKeywords = {
    date: [
      "날짜", "날자", "date", "Date", "판매일", "판매일자", "작성일", "일자",
      "작성일자", "거래일", "거래일자", "구매일", "구매일자", "등록일", "등록일자",
      "주문일", "주문일자", "처리일", "처리일자", "결제일", "결제일자"
    ],
    name: [
        "제품", "상품", "상품명", "제품명", "품명", "아이템", "품목", "항목", "name", "Name", "item", "Item",
        "제품코드", "상품코드", "제품ID", "제품id", "상품ID", "상품id", "제품이름", "상품이름", "모델명", "model", 
        "Model", "product", "Product", "제품명칭", "상품명칭"
      ],
    price: [
        "가격", "단가", "판매가", "판매가격", "구매가", "구매가격", "Price", "price", "unit price", "Unit Price",
        "금액", "상품금액", "제품금액", "금액(단위:원)", "금액(KRW)", "금액(USD)", "cost", "Cost", "원가", "정가",
        "소비자가", "공급가", "공급단가", "list price", "retail price", "거래단가", "결제금액"
      ],      
    amount: [
      "매출", "매출액", "sales", "Sales", "revenue", "Revenue", "금액",
      "판매금액", "총액", "수익", "amount", "Amount", "실매출", "매출합계",
      "총매출", "결제금액", "order total", "total price", "거래금액"
    ],
    quantity: [
        "수량", "개수", "판매수량", "구매수량", "출고수량", "주문수량", "Qty", "QTY", "qty", "quantity", "Quantity",
        "갯수", "개", "pcs", "PCS", "수", "수량(개)", "수량(PCS)", "수량수", "unit", "Unit", "units", "Units"
      ],
    currency: ["통화", "currency", "Currency", "화폐", "화폐단위"]
  };

let cachedRate = null;
const TEST_EXCHANGE_RATE = 1350; // 테스트 끝나면 반드시 null로 바꿔야 함

// 환율
export async function fetchExchangeRate(base = "USD", target = "KRW") {
  // ✅ 테스트용 환율 강제 적용
  if (TEST_EXCHANGE_RATE !== null) {
    console.warn("🧪 [TEST MODE] 임의의 환율 사용:", TEST_EXCHANGE_RATE);
    return TEST_EXCHANGE_RATE;
  }

  if (cachedRate !== null) return cachedRate;

  const apiKey = "8e92fa60cab77caca2162ef3";
  const res = await axios.get(`https://v6.exchangerate-api.com/v6/${apiKey}/latest/${base}`);
  const rate = res?.data?.conversion_rates?.[target];

  if (!rate) {
    console.warn("⚠️ 환율 데이터 비정상:", res?.data);
    throw new Error(`환율 (${base}→${target}) 정보 없음`);
  }

  cachedRate = rate;
  return rate;
}
  
  

  
