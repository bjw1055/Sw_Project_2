import React, { useState, useEffect } from "react";
import axios from "axios";
import UploadSection from "./UploadSection";
import DataTable from "./DataTable";
import ChartSection from "./ChartSection";
import AIPredictionResult from "./AIPredictionResult";

export default function Dashboard({ user, project, onLogout, onBack }) {
  const [csvData, setCsvData] = useState([]);
  const [aiResult, setAiResult] = useState(null);
  const [showAllRows, setShowAllRows] = useState(false);
  const [sortConfig, setSortConfig] = useState({ key: null, direction: "asc" });
  const [projectTitle, setProjectTitle] = useState("");

  useEffect(() => {
    if (project?.title) {
      setProjectTitle(project.title);
    }

    const fetchInitialData = async () => {
      try {
        //업로드된 원본 데이터 불러오기
        const res1 = await axios.get(`http://localhost:5000/api/products?projectId=${project.id}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        setCsvData(res1.data);

        //예측 결과도 같이 요청 (있으면 표시됨)
        const res2 = await axios.post(`http://localhost:5000/api/predict`, {
          projectId: project.id
        }, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        setAiResult(res2.data);
        console.log("AI 예측 결과:", res2.data); //ㅌㅅㅌ
      } catch (err) {
        console.warn("초기 대시보드 데이터 로딩 실패:", err); //ㅌㅅㅌ
      }
    };

    if (project?.id) {
      fetchInitialData();
    }
  }, [project]);

  const handleSort = (key) => {
    let direction = "asc";
    if (sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc";
    }
    setSortConfig({ key, direction });
  };

  return (
    <div className="dashboard-wrapper">
      <header className="header">
        <div className="header-section left"></div>
        <img src="../assets/logo.png" alt="logo" className="logo-img" />
        <div className="header-right-column"></div>
      </header>

      <div className="upload-back-button-wrapper">
        <button className="back-button" onClick={onBack}>
            ← 보고서 목록으로
        </button>
      </div>

      <UploadSection
        selectedProject={project}
        setAiResult={setAiResult}
        onUploadSuccess={setCsvData}
      />

      <DataTable
        data={csvData}
        showAll={showAllRows}
        setShowAll={setShowAllRows}
        sortConfig={sortConfig}
        handleSort={handleSort}
      />

      <AIPredictionResult aiResult={aiResult} />
      
      {csvData.length === 0 ? (
      <EmptyChart /> // 기본 이미지나 텍스트 출력
    ) : (
      <ChartSection
        csvData={csvData}
        aiResult={aiResult}
        project={project}
      />
    )}
    </div>
  );
}

function EmptyChart() {
    return (
      <div className="chart-empty">
        <img src="/assets/empty-chart.jpg" alt="No chart data" className="empty-chart-img" />
        <p>데이터를 업로드하면 대시보드가 표시됩니다.</p>
      </div>
    );
  }