import React, { useState, useEffect } from "react";
import axios from "axios";
import UploadSection from "./UploadSection";
import DataTable from "./DataTable";
import ChartSection from "./ChartSection";
// import AIPredictionResult from "./AIPredictionResult";
import { fetchExchangeRate, columnKeywords, guessColumn } from "./utils";

export default function Dashboard({ project, onBack }) {
  const [csvData, setCsvData] = useState([]);
  const [aiResult, setAiResult] = useState(null);
  const [showAllRows, setShowAllRows] = useState(false);
  const [sortConfig, setSortConfig] = useState({ key: null, direction: "asc" });
  const [projectTitle, setProjectTitle] = useState("");
  const [uploadedFileNames, setUploadedFileNames] = useState([]);

  useEffect(() => {
    if (project?.title) setProjectTitle(project.title);
    if (project?.id) fetchDataFromDB();
  }, [project]);

  const handleBackToList = () => {
    window.history.pushState({}, '', '/'); // URL 변경!
    onBack(); // 기존 상태 변경
  };  

  const applyExchangeRateToData = async (rawUploadData) => {
    const rate = await fetchExchangeRate();
    return rawUploadData.map(row => {
      const raw = { ...row.raw_data };
      const keys = Object.keys(raw);
      const currencyKey = guessColumn(keys, columnKeywords.currency);
      const amountKey = guessColumn(keys, columnKeywords.amount);
      const currency = raw[currencyKey];

      if (currency === "USD" && amountKey && !isNaN(parseFloat(raw[amountKey]))) {
        raw[amountKey] = parseFloat(raw[amountKey]) * rate;
      }

      return { ...row, raw_data: raw };
    });
  };

  const fetchDataFromDB = async () => {
    try {
      const res1 = await axios.get(`http://localhost:5000/api/products?projectId=${project.id}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      const converted = await applyExchangeRateToData(res1.data);
      setCsvData(converted);
      setUploadedFileNames([...new Set(res1.data.map(row => row.filename).filter(Boolean))]);
      await requestPrediction();
    } catch (err) {
      console.warn("초기 대시보드 데이터 로딩 실패:", err);
    }
  };

  const handleUploadSuccess = async (rawUploadData) => {
    const converted = await applyExchangeRateToData(rawUploadData);
    setCsvData(converted);
    setUploadedFileNames([...new Set(rawUploadData.map(row => row.filename).filter(Boolean))]);
    await requestPrediction();
  };

  const requestPrediction = async () => {
    try {
      const res = await axios.post("http://localhost:5000/api/predict", {
        projectId: project.id,
      }, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      setAiResult(res.data);
      console.log("📈 AI 예측 결과:", res.data);
    } catch (err) {
      console.warn("❌ AI 예측 실패:", err);
    }
  };

  const handleSort = (key) => {
    const direction = sortConfig.key === key && sortConfig.direction === "asc" ? "desc" : "asc";
    setSortConfig({ key, direction });
  };

  return (
    <div className="dashboard-wrapper">
      <header className="header">
        <div className="header-section left" />
        <img src="../assets/logo.png" alt="logo" className="logo-img" />
        <div className="header-right-column" />
      </header>

      <div className="upload-back-button-wrapper">
        <button className="back-button" onClick={handleBackToList}>← 보고서 목록으로</button>
      </div>

      <UploadSection
        selectedProject={project}
        setAiResult={setAiResult}
        onUploadSuccess={handleUploadSuccess}
        uploadedFileNames={uploadedFileNames}
      />

      <DataTable
        data={csvData}
        showAll={showAllRows}
        setShowAll={setShowAllRows}
        sortConfig={sortConfig}
        handleSort={handleSort}
      />

      {/* <AIPredictionResult aiResult={aiResult} /> */}

      {csvData.length === 0 ? (
        <EmptyChart />
      ) : (
        <ChartSection csvData={csvData} aiResult={aiResult} project={project} />
      )}
    </div>
  );
}

function EmptyChart() {
  return (
    <div className="chart-empty">
      <img src="/assets/empty-chart.jpg" alt="No chart data" className="empty-chart-img" />
      <p>데이터를 업로드하면 대시보드가 표시됩니다.</p>
    </div>
  );
}
