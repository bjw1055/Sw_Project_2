
import React, { useEffect, useState } from "react";
import { Bar, Line, Pie } from "react-chartjs-2";
import { guessColumn, columnKeywords, parseExcelDate } from "./utils";
import {
  Chart as ChartJS,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  CategoryScale,
  LinearScale,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  CategoryScale,
  LinearScale,
  Title,
  Tooltip,
  Legend
);

export default function ChartSection({ csvData, aiResult, project }) {
  const [barData, setBarData] = useState({});
  const [lineData, setLineData] = useState({});
  const [pieData, setPieData] = useState({});
  const [aiLineData, setAiLineData] = useState({});
  const [total, setTotal] = useState(0);
  const [quantity, setQuantity] = useState(0);

  useEffect(() => {
    if (!csvData?.length) return;

    const sample = csvData[0].raw_data || {};
    const keys = Object.keys(sample);
    const nameKey = guessColumn(keys, columnKeywords.name);
    const amountKey = guessColumn(keys, columnKeywords.amount);
    const quantityKey = guessColumn(keys, columnKeywords.quantity);
    const dateKey = guessColumn(keys, columnKeywords.date);

    const productMap = {};
    const dateMap = {};
    const colors = ["#3399FF", "#66CCFF", "#99CCFF", "#CCCCFF", "#6699CC", "#003366"];

    let totalAmount = 0;
    let totalQty = 0;

    csvData.forEach((row) => {
      const raw = row.raw_data || {};
      const name = raw[nameKey] || "기타";
      const amount = Number(raw[amountKey] || 0);
      const qty = Number(raw[quantityKey] || 0);
      const date = parseExcelDate(raw[dateKey]);

      productMap[name] = (productMap[name] || 0) + amount;
      dateMap[date] = (dateMap[date] || 0) + amount;

      totalAmount += amount;
      totalQty += qty;
    });

    setBarData({
      labels: Object.keys(productMap),
      datasets: [
        {
          label: "제품별 매출 (KRW)",
          data: Object.values(productMap),
          backgroundColor: colors,
        },
      ],
    });

    const sortedDates = Object.keys(dateMap).sort();
    setLineData({
      labels: sortedDates,
      datasets: [
        {
          label: "날짜별 매출 (KRW)",
          data: sortedDates.map((d) => dateMap[d]),
          borderColor: "#36A2EB",
          tension: 0.3,
        },
      ],
    });

    setPieData({
      labels: Object.keys(productMap),
      datasets: [
        {
          label: "제품별 비중",
          data: Object.values(productMap),
          backgroundColor: colors,
        },
      ],
    });

    setTotal(totalAmount);
    setQuantity(totalQty);
  }, [csvData]);

  useEffect(() => {
    if (!aiResult?.forecast_next_7_days) return;

    const labels = Object.keys(aiResult.forecast_next_7_days);
    const values = Object.values(aiResult.forecast_next_7_days);

    setAiLineData({
      labels,
      datasets: [
        {
          label: "AI 예측 매출 (KRW)",
          data: values,
          borderColor: "#3366cc",
          tension: 0.3,
        },
      ],
    });
  }, [aiResult]);

  const avgPrice = quantity > 0 ? total / quantity : 0;

  return (
    <div className="dashboard-container">
      <h2 className="dashboard-title">
        [{project?.title || "보고서"} 매출 현황 보고서]
      </h2>
  
      <div className="dashboard-grid">
        {/* ✅ 날짜별 매출 (Line) */}
        <div className="line-chart chart-box">
          <h3>날짜별 매출</h3>
          <div style={{ height: "280px" }}>
            {lineData?.labels?.length ? (
              <Line
                data={lineData}
                options={{ maintainAspectRatio: false }}
              />
            ) : (
              <EmptyChart />
            )}
          </div>
        </div>
  
        {/* ✅ 제품별 매출 (Bar) */}
        <div className="bar-chart chart-box">
          <div style={{ height: "850px", width: "100%" }}>
            {barData?.labels?.length ? (
              <Bar
                data={{ ...barData, indexAxis: "y" }}
                options={{
                  indexAxis: "y",
                  responsive: true,
                  maintainAspectRatio: false,
                  layout: { padding: 0 },
                  plugins: {
                    legend: { display: false },
                    title: {
                      display: true,
                      text: "제품별 매출액",
                      align: "start",
                      padding: { top: 20, bottom: 30 },
                      font: { size: 19, weight: "bold" },
                      color: "#333",
                    },
                  },
                }}
              />
            ) : (
              <EmptyChart />
            )}
          </div>
        </div>
  
        {/* ✅ 파이차트 */}
        <div className="pie-chart chart-box">
          <h3>제품별 매출 비중</h3>
          <div style={{ height: "350px", width: "100%" }}>
            {pieData?.labels?.length ? (
              <Pie
                data={pieData}
                options={{ maintainAspectRatio: false }}
              />
            ) : (
              <EmptyChart />
            )}
          </div>
        </div>
  
        {/* ✅ 통계 카드 */}
        <div className="stat-cards">
          <div className="stat-card">💰 총 매출<br /><strong>{total.toLocaleString()} 원</strong></div>
          <div className="stat-card">📦 총 수량<br /><strong>{quantity.toLocaleString()} 개</strong></div>
          <div className="stat-card">💳 평균 단가<br /><strong>{avgPrice.toLocaleString()} 원</strong></div>
          {aiResult?.forecast_next_7_days && (
            <div className="stat-card">
              <h3 className="font-semibold mb-2">🤖 AI 예측 통계</h3>
              <ul className="ai-forecast-list">
                <li>총 매출: {aiResult.total_sales?.toLocaleString()}원</li>
                <li>평균 매출: {aiResult.avg_sales?.toLocaleString()}원</li>
                <li>최대 매출: {aiResult.max_sales?.toLocaleString()}원</li>
                <li>최소 매출: {aiResult.min_sales?.toLocaleString()}원</li>
              </ul>
              <br />
              <h3 className="font-semibold mt-2">📅 향후 7일 예측</h3>
              <ul className="ai-forecast-list">
                {Object.entries(aiResult.forecast_next_7_days).map(([date, forecast], idx) => (
                  <li key={idx}>
                    {new Date(date).toISOString().substring(0, 10)}: {forecast.toLocaleString()}원
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
  
        {/* ✅ AI 예측 결과 */}
        <div className="forecast-chart chart-box">
          <h3>AI 매출 예측 결과</h3>
          <div style={{ height: "400px", width: "100%" }}>
            {aiLineData?.labels?.length ? (
              <Line
                data={aiLineData}
                options={{ maintainAspectRatio: false }}
              />
            ) : (
              <EmptyChart />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}  

function EmptyChart() {
  return (
    <div className="chart-empty">
      <p>No chart data available</p>
    </div>
  );
}