import React from "react";
import { columnKeywords, parseExcelDate, getMajorityColumn, getValueByFallback, fetchExchangeRate } from "./utils";
import { useEffect, useState } from "react";

export default function DataTable({
  data = [],
  showAll,
  setShowAll,
  sortConfig = {},
  handleSort
}) {

  const [exchangeRate, setExchangeRate] = useState(1);

  useEffect(() => {
    fetchExchangeRate("USD", "KRW").then((rate) => {
      if (rate) setExchangeRate(rate);
    });
  }, []);

  const previewData = data.filter(
    (row) => row.raw_data?.name !== "예측데이터"
  );

  const dateKey = getMajorityColumn(previewData, columnKeywords.date);
  const nameKey = getMajorityColumn(previewData, columnKeywords.name);
  const quantityKey = getMajorityColumn(data, columnKeywords.quantity);
  const priceKey = getMajorityColumn(data, columnKeywords.price);
  const amountKey = getMajorityColumn(data, columnKeywords.amount);
  
  const sortedData = React.useMemo(() => {
    let items = Array.isArray(previewData) ? [...previewData] : [];
    if (sortConfig.key) {
      items.sort((a, b) => {
        const valA = a.raw_data?.[sortConfig.key];
        const valB = b.raw_data?.[sortConfig.key];
        if (typeof valA === "number" && typeof valB === "number") {
          return sortConfig.direction === "asc" ? valA - valB : valB - valA;
        } else if (typeof valA === "string" && typeof valB === "string") {
          return sortConfig.direction === "asc"
            ? valA.localeCompare(valB)
            : valB.localeCompare(valA);
        }
        return 0;
      });
    }
    return items;
  }, [previewData, sortConfig]);

  const displayData = showAll ? sortedData : sortedData.slice(0, 5);

  const hasBrokenColumns = displayData.some(row => {
    const raw = row.raw_data || {};
    return Object.keys(raw).some(key => key.includes("�"));
  });
  
  return (
    <>
      <h3 className="preview-title">
        📊 데이터 미리보기{" "}
        {exchangeRate && (
          <span className="currency-message">
            (현재 환율: 1 USD ≈ {exchangeRate.toLocaleString()} KRW)
          </span>
        )}
      </h3>
      {hasBrokenColumns && (
        <div className="encoding-warning">
          일부 파일에서 인코딩 문제가 감지되어 데이터가 깨졌습니다.<br />
          해당 CSV 파일을 <strong>UTF-8</strong> 형식으로 저장한 후 다시 업로드해 주세요.
        </div>
      )}
      <div className="table-wrapper">
        <table className="custom-table">
          <thead>
            <tr>
              <th onClick={() => handleSort(dateKey || "date")}>날짜</th>
              <th onClick={() => handleSort(nameKey || "name")}>제품명</th>
              <th onClick={() => handleSort(quantityKey || "quantity")}>수량</th>
              <th onClick={() => handleSort(priceKey || "price")}>가격</th>
              <th onClick={() => handleSort(amountKey || "amount")}>매출액(KRW)</th>
            </tr>
          </thead>
          <tbody>
          {displayData.map((row, index) => {
            const raw = row.raw_data || {};

            const dateVal = getValueByFallback(raw, dateKey, columnKeywords.date);
            const name = getValueByFallback(raw, nameKey, columnKeywords.name);
            const quantity = getValueByFallback(raw, quantityKey, columnKeywords.quantity);
            const price = getValueByFallback(raw, priceKey, columnKeywords.price);
            const amount = getValueByFallback(raw, amountKey, columnKeywords.amount);

              return (
                <tr key={index}>
                  <td>{parseExcelDate(dateVal)}</td>
                  <td>{name}</td>
                  <td>{quantity}</td>
                  <td>{Number(price).toLocaleString()}</td>
                  <td>{Number(amount).toLocaleString()}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <div className="table-toggle">
        <button className="table-toggle" onClick={() => setShowAll(!showAll)}>
          {showAll ? "간략히 보기 🔼" : "전체 보기 🔽"}
        </button>
      </div>
    </>
  );
}
