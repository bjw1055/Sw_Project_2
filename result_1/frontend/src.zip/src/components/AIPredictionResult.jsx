import React from "react";

export default function AIPredictionResult({ aiResult }) {
  console.log("🔥 AIPredictionResult aiResult:", aiResult);
  // const isValidResult = aiResult &&
  //   (aiResult.total_sales || aiResult.avg_sales || aiResult.max_sales || aiResult.min_sales ||
  //    aiResult.product_summary || aiResult.forecast_next_7_days);

  const isValidResult = aiResult && (
    aiResult.total_sales !== undefined ||
    aiResult.forecast_next_7_days !== undefined
  );  

  if (!isValidResult) return null;

  return (
    <div className="ai-result">
      <h3>🤖 AI 분석 결과</h3>
      <ul>
        {aiResult.total_sales && <li>총 매출: {aiResult.total_sales.toLocaleString()}원</li>}
        {aiResult.avg_sales && <li>평균 매출: {aiResult.avg_sales.toLocaleString()}원</li>}
        {aiResult.max_sales && <li>최대 매출: {aiResult.max_sales.toLocaleString()}원</li>}
        {aiResult.min_sales && <li>최소 매출: {aiResult.min_sales.toLocaleString()}원</li>}
      </ul>

      {aiResult.product_summary && (
        <>
          <h4>제품별 매출 요약</h4>
          <ul>
            {Object.entries(aiResult.product_summary).map(([product, amount]) => (
              <li key={product}>{product}: {amount.toLocaleString()}원</li>
            ))}
          </ul>
        </>
      )}

      {aiResult.forecast_next_7_days && (
        <>
          <h4>향후 7일 예측 매출액</h4>
          <ul>
            {Object.entries(aiResult.forecast_next_7_days).map(([date, forecast], idx) => (
              <li key={idx}>
                {new Date(date).toISOString().substring(0, 10)}: {forecast.toLocaleString()}원
              </li>
            ))}
          </ul>
        </>
      )}

      {aiResult.chart_image && (
        <div className="ai-chart-preview">
          <h4>예측 차트 미리보기</h4>
          <img
            src={`http://localhost:5000/${aiResult.chart_image.replace(/\\/g, "/")}`}
            alt="예측 차트"
            style={{ maxWidth: "600px", marginTop: "10px" }}
          />
        </div>
      )}

      {aiResult.outlier_image && (
        <div style={{ marginTop: "20px" }}>
          <h4>이상치 차트 미리보기</h4>
          <img
            src={`http://localhost:5000/${aiResult.outlier_image}`}
            alt="이상치 추이"
            style={{ maxWidth: "100%", height: "auto" }}
          />
        </div>
      )}
    </div>
  );
}
