import React from 'react';
import { guessColumn, columnKeywords } from "./utils";

export default function StatsSection({ csvData }) {
  if (!csvData.length) return null;

  const sample = csvData[0].raw_data || {};
  const keys = Object.keys(sample);

  const amountKey = guessColumn(keys, columnKeywords.amount);
  const quantityKey = guessColumn(keys, columnKeywords.quantity);

  const totalKRW = csvData.reduce(
    (sum, row) => sum + Number(row.raw_data?.[amountKey] || 0),
    0
  );
  const totalQty = csvData.reduce(
    (sum, row) => sum + Number(row.raw_data?.[quantityKey] || 0),
    0
  );

  const avgPrice = totalQty > 0 ? totalKRW / totalQty : 0;
}