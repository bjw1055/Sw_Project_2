const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const dataController = require('../controllers/dataController');
const { verifyToken } = require('../middleware/auth');;

// 📁 업로드 파일 저장 설정
const storage = multer.diskStorage({
  destination: './uploads/',
  filename: (req, file, cb) => {
    const timestamp = Date.now();
    const ext = path.extname(file.originalname);
    cb(null, `upload-${timestamp}${ext}`);
  },
});
const upload = multer({ storage });


//1. CSV 또는 Excel 업로드 (projectId 필요)
router.post('/upload', verifyToken, upload.array('files'), dataController.uploadMultipleFilesWithProject);


//2. 분석 항목 생성 및 조회
router.post('/projects', verifyToken, dataController.createProject);
router.get('/projects', verifyToken, dataController.getProjects);

router.get('/products', (req, res, next) => {
  next();
}, verifyToken, dataController.getProducts);


//3. 예측 분석 (projectId 필요)
router.post('/predict', verifyToken, dataController.getPredictionWithProject);


//4. 전체/범위 데이터 조회
router.get('/data', verifyToken, dataController.getData);
router.get('/data-with-outliers', verifyToken, dataController.getDataWithOutliers);


//5. 단건 보고서 조회
router.get('/projects/:id', verifyToken, dataController.getProjectById);

//6. 보고서 삭제
router.delete('/projects/:id', verifyToken, dataController.deleteProjectById);

module.exports = router;
