const fs = require('fs');
const path = require('path');
const csv = require('csv-parser');
const db = require('../db');
const { spawn } = require('child_process');
const xlsx = require('xlsx');

// CSV 또는 Excel 업로드 (projectId 포함)
exports.uploadMultipleFilesWithProject = async (req, res) => {
  const projectId = req.body.projectId;
  const userId = req.user?.userId;
  const files = req.files;

  if (!files?.length || !projectId || !userId) {
    return res.status(400).json({ error: "유효한 데이터가 없습니다." });
  }

  const allRows = [];

  const parseFile = (file) => {
    return new Promise((resolve, reject) => {
      const ext = path.extname(file.path).toLowerCase();

      if (ext === ".csv") {
        const rows = [];
        fs.createReadStream(file.path)
          .pipe(csv())
          .on("data", (data) => rows.push(data))
          .on("end", () => resolve(rows))
          .on("error", (err) => reject(err));
      } else if (ext === ".xlsx") {
        try {
          const workbook = xlsx.readFile(file.path);
          const sheet = workbook.Sheets[workbook.SheetNames[0]];
          const rows = xlsx.utils.sheet_to_json(sheet);
          resolve(rows);
        } catch (err) {
          reject(err);
        }
      } else {
        reject(new Error("지원하지 않는 파일 형식"));
      }
    });
  };

  const deleteOldData = () => {
    return new Promise((resolve, reject) => {
      const sql = "DELETE FROM products WHERE project_id = ?";
      db.query(sql, [projectId], (err) => {
        if (err) return reject(err);
        console.log(`🧹 기존 데이터 삭제 완료 - project_id=${projectId}`);
        resolve();
      });
    });
  };

  const insertParsedRows = (rows) => {
    const insertQuery = "INSERT INTO products (project_id, raw_data) VALUES ?";
    const values = rows.map((r) => [projectId, JSON.stringify(r)]);
    db.query(insertQuery, [values], (err, result) => {
      if (err) {
        console.error("DB 삽입 오류:", err);
        return res.status(500).json({ error: "DB 오류" });
      }
      res.json({ message: "업로드 성공", inserted: result.affectedRows });
    });
  };

  try {
    await deleteOldData();

    for (const file of files) {
      const parsed = await parseFile(file);
      allRows.push(...parsed);
    }

    console.log("📦 병합된 rows.length:", allRows.length);
    insertParsedRows(allRows);
  } catch (err) {
    console.error("❌ 파싱 또는 DB 오류:", err);
    res.status(500).json({ error: "업로드 처리 중 오류 발생" });
  }
};


// 날짜 범위 지원 + 전체 데이터 조회
exports.getData = (req, res) => {
  const { start, end } = req.query;
  let sql = 'SELECT * FROM products';
  const values = [];
  
  if (start && end) {
    sql += ' WHERE uploaded_at BETWEEN ? AND ?';
    values.push(start, end);
  }

  db.query(sql, values, (err, results) => {
    if (err) {
      console.error('DB 조회 실패:', err);
      return res.status(500).json({ error: 'DB 조회 실패' });
    }
    res.json(results);
  });
};

// 이상치 탐지용 API
exports.getDataWithOutliers = (req, res) => {
  const sql = 'SELECT date, amount FROM products ORDER BY uploaded_at ASC';
  db.query(sql, (err, results) => {
    if (err) {
      console.error('DB 조회 실패:', err);
      return res.status(500).json({ error: 'DB 조회 실패' });
    }

    const values = results.map(r => r.amount);
    const avg = values.reduce((a, b) => a + b, 0) / values.length;
    const threshold = avg * 1.5;

    const dataWithOutliers = results.map(row => ({
      date: row.date,
      amount: row.amount,
      outlier: row.amount > threshold || row.amount < avg / 1.5,
    }));

    res.json(dataWithOutliers);
  });
};

// 분석 항목 생성
exports.createProject = (req, res) => {
  const { title } = req.body;
  const userId = req.user?.userId;
  console.log("🧪 title:", title);
  console.log("🧪 userId:", userId);
  if (!userId || !title) {
    return res.status(400).json({ error: '제목과 사용자 정보가 필요합니다.' });
  }

  const sql = 'INSERT INTO analysis_projects (user_id, title) VALUES (?, ?)';
  db.query(sql, [userId, title], (err, result) => {
    if (err) {
      console.error('항목 생성 실패:', err);
      return res.status(500).json({ error: 'DB 오류' });
    }
    res.json({ message: '항목 생성 성공', id: result.insertId });
  });
};

// ✅ 특정 프로젝트 단건 조회
exports.getProjectById = (req, res) => {
  const { id } = req.params;
  const userId = req.user?.userId;

  if (!userId) {
    return res.status(401).json({ error: '인증된 사용자만 접근 가능합니다.' });
  }

  const sql = 'SELECT id, title, created_at FROM analysis_projects WHERE id = ? AND user_id = ?';
  db.query(sql, [id, userId], (err, results) => {
    if (err) {
      console.error('프로젝트 단건 조회 실패:', err);
      return res.status(500).json({ error: 'DB 조회 실패' });
    }
    if (results.length === 0) {
      return res.status(404).json({ error: '프로젝트를 찾을 수 없습니다.' });
    }
    res.json(results[0]);
  });
};

// ✅ 특정 프로젝트 삭제
exports.deleteProjectById = (req, res) => {
  const { id } = req.params;
  const userId = req.user?.userId;

  if (!userId) {
    return res.status(401).json({ error: '인증된 사용자만 접근 가능합니다.' });
  }

  const deleteProjectSql = 'DELETE FROM analysis_projects WHERE id = ? AND user_id = ?';
  const deleteProductsSql = 'DELETE FROM products WHERE project_id = ?';

  // 🔁 관련 데이터 먼저 정리 (products 등)
  db.query(deleteProductsSql, [id], (err) => {
    if (err) {
      console.error('products 삭제 실패:', err);
      return res.status(500).json({ error: 'products 삭제 실패' });
    }

    db.query(deleteProjectSql, [id, userId], (err, result) => {
      if (err) {
        console.error('프로젝트 삭제 실패:', err);
        return res.status(500).json({ error: '프로젝트 삭제 실패' });
      }

      if (result.affectedRows === 0) {
        return res.status(404).json({ error: '삭제할 프로젝트를 찾을 수 없습니다.' });
      }

      res.json({ message: '프로젝트가 성공적으로 삭제되었습니다.' });
    });
  });
};

exports.getProducts = (req, res) => {
  const projectId = req.query.projectId;
  const userId = req.user?.userId;

  console.log("🔍 getProducts 호출 - projectId:", projectId);

  if (!projectId || !userId) {
    return res.status(400).json({ error: 'projectId와 사용자 정보가 필요합니다.' });
  }

  const sql = 'SELECT * FROM products WHERE project_id = ? ORDER BY uploaded_at ASC';
  db.query(sql, [projectId], (err, results) => {
    if (err) {
      console.error('DB 조회 실패:', err);
      return res.status(500).json({ error: 'DB 조회 실패' });
    }
    console.log("🧼 반환할 데이터 개수:", results.length);
    res.json(results);
  });
};

// 분석 항목 조회
exports.getProjects = (req, res) => {
  const userId = req.user?.userId;
  
  const sql = 'SELECT id, title, created_at FROM analysis_projects WHERE user_id = ? ORDER BY created_at DESC';
  db.query(sql, [userId], (err, results) => {
    if (err) {
      console.error('항목 조회 실패:', err);
      return res.status(500).json({ error: 'DB 조회 실패' });
    }
    res.json(results);
  });
};

// 예측 결과: 최신 모델 analyze_sales.py 실행
exports.getPredictionWithProject = (req, res) => {
  const projectId = req.body.projectId;
  if (!projectId) {
    return res.status(400).json({ error: 'projectId가 필요합니다.' });
  }

  const scriptPath = path.join(__dirname, '../analyze_sales.py');

  const python = spawn('python3', [scriptPath, '--project', projectId]);

  let result = '';
  let errorLog = '';

  python.stdout.on('data', (data) => {
    result += data.toString();
  });  

  python.stderr.on('data', (data) => {
    errorLog += data.toString();
    console.error(`Python stderr: ${data}`);
  });

  python.on('close', () => {
    try {
      const trimmed = result.toString().trim(); // 문자열로 변환 후 trim
      if (!trimmed) throw new Error('Python 출력이 비어 있습니다.');
      const parsed = JSON.parse(trimmed);
      res.json(parsed);
    } catch (err) {
      console.error('예측 결과 파싱 실패:', err);
      res.status(500).json({ error: '예측 결과 파싱 실패', details: errorLog });
    }
  });
};
