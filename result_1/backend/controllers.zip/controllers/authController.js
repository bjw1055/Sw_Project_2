const db = require('../db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const SECRET_KEY = process.env.JWT_SECRET;

// 회원가입
exports.register = async (req, res) => {
  const { email, password } = req.body;

  try {
    const hashed = await bcrypt.hash(password, 10);

    db.query(
      'INSERT INTO users (email, password_hash) VALUES (?, ?)',
      [email, hashed],
      (err, result) => {
        if (err) {
          console.error('회원가입 실패:', err);
          return res.status(500).json({ error: '회원가입 실패' });
        }
        res.json({ message: '회원가입 성공' });
      }
    );
  } catch (err) {
    console.error('해싱 실패:', err);
    res.status(500).json({ error: '비밀번호 해싱 실패' });
  }
};

// 로그인
exports.login = (req, res) => {
    const { email, password } = req.body;
  
    db.query('SELECT * FROM users WHERE email = ?', [email], async (err, results) => {
      if (err || results.length === 0) {
        return res.status(401).json({ error: '유효하지 않은 사용자' });
      }
  
      const user = results[0];
      const match = await bcrypt.compare(password, user.password_hash);
  
      if (!match) {
        return res.status(401).json({ error: '비밀번호 불일치' });
      }
  
      const token = jwt.sign(
        { userId: user.id, email: user.email },
        SECRET_KEY,
        { expiresIn: '10h' }
      );
  
      // 응답 전에 로그인 정보와 토큰 로그로 출력
      console.log('로그인 성공:', { user, token });
  
      res.json({ message: '로그인 성공', token, user });
    });
  };
  
