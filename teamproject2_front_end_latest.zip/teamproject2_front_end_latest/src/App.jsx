import React, { useState, useEffect } from "react";
import axios from "axios";
import { Bar, Line, Pie } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Tooltip,
  Legend,
} from "chart.js";
import "./App.css";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Tooltip,
  Legend
);

function App() {
  const [csvData, setCsvData] = useState([]);
  const [file, setFile] = useState(null);
  const [showAllRows, setShowAllRows] = useState(false);
  const [aiResult, setAiResult] = useState(null); // 예측 결과 저장
  const [chartData, setChartData] = useState({});
  const [lineData, setLineData] = useState({});
  const [pieData, setPieData] = useState({});
  const [activeChart, setActiveChart] = useState("bar");
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [sortConfig, setSortConfig] = useState({ key: null, direction: "asc" });


  const sortedData = React.useMemo(() => {
    let sortableItems = [...csvData];
    if (sortConfig.key) {
      sortableItems.sort((a, b) => {
        const valA = a[sortConfig.key];
        const valB = b[sortConfig.key];

        if (typeof valA === "number" && typeof valB === "number") {
          return sortConfig.direction === "asc" ? valA - valB : valB - valA;
        } else {
          return sortConfig.direction === "asc"
            ? valA.localeCompare(valB)
            : valB.localeCompare(valA);
        }
      });
    }
    return sortableItems;
  }, [csvData, sortConfig]);


  const handleSort = (key) => {
    if (!showAllRows) return;
    let direction = "asc";
    if (sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc";
    }
    setSortConfig({ key, direction });
  };




  useEffect(() => {
    if (isDarkMode) {
      document.body.classList.add("dark");
    } else {
      document.body.classList.remove("dark");
    }
  }, [isDarkMode]);



  const displayData = showAllRows ? csvData : csvData.slice(0, 5);
  const totalKRW = csvData.reduce((sum, row) => sum + Number(row.amount), 0);
  const totalQty = csvData.reduce((sum, row) => sum + Number(row.quantity), 0);
  const avgPrice = totalQty > 0 ? totalKRW / totalQty : 0;


  const fetchChartData = async () => {
    try {
      const response = await axios.get("http://localhost:5000/api/products");
      const data = response.data;

      const colors = ["#FF6384", "#36A2EB", "#FFCE56", "#4BC0C0",
        "#9966FF", "#FF9F40", "#66DDAA", "#C71585",
        "#87CEFA", "#FFA07A", "#20B2AA", "#FFB6C1",
      ];

      const productMap = {};
      data.forEach(row => {
        if (productMap[row.name]) {
          productMap[row.name] += row.amount;
        } else {
          productMap[row.name] = row.amount;
        }
      });

      const bar = {
        labels: Object.keys(productMap),
        datasets: [{ label: "제품별 매출(KRW)", data: Object.values(productMap), backgroundColor: colors, }],
      };

      const dateMap = {};
      data.forEach(row => {
        const dateOnly = row.date.slice(0, 10);
        if (dateMap[dateOnly]) {
          dateMap[dateOnly] += row.amount;
        } else {
          dateMap[dateOnly] = row.amount;
        }
      });

      const sortedDates = Object.keys(dateMap).sort();
      const line = {
        labels: sortedDates,
        datasets: [{ label: "날짜별 매출(KRW)", data: sortedDates.map(d => dateMap[d]), borderColor: "#36A2EB" }],
      };

      const pie = {
        labels: Object.keys(productMap),
        datasets: [{ label: "제품별 매출 비중", data: Object.values(productMap), backgroundColor: colors, }],
      };

      setChartData(bar);
      setLineData(line);
      setPieData(pie);
    } catch (err) {
      console.error("차트 데이터 로딩 실패:", err);
    }
  };



  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const [uploadError, setUploadError] = useState("");

  const handleUpload = async () => {
    setUploadError(""); //에러 메세지 초기화

    if (!file || !file.name.endsWith(".csv")) {
      alert("CSV 파일만 업로드 가능합니다.");
      return;
    }

    const formData = new FormData();
    formData.append("file", file); // ✅ 변경됨

    try {
      await axios.post("http://localhost:5000/api/upload", formData);
      const res = await axios.get("http://localhost:5000/api/products");
      setCsvData(res.data);

      await fetchChartData();
    } catch (error) {
      console.error("업로드 실패:", error);
    }
  };

  const handlePredict = async () => {
    const formData = new FormData();
    formData.append("csv", file); // ✅ /predict 는 csv 필드 사용 중

    try {
      const response = await axios.post("http://localhost:5000/api/predict", formData);
      console.log("AI 예측 결과:", response.data);
      setAiResult(response.data); // 예측 결과 저장
    } catch (err) {
      console.error("예측 실패:", err);
    }
  };

  const renderChart = () => {
    if (activeChart === "bar" && chartData?.labels?.length) {
      return <Bar data={chartData} options={{ responsive: true }} />;
    } else if (activeChart === "line" && lineData?.labels?.length) {
      return <Line data={lineData} options={{ responsive: true }} />;
    } else if (activeChart === "pie" && pieData?.labels?.length) {
      return <Pie data={pieData} options={{ responsive: true }} />;
    }
    return null;
  };

  return (
    <div className={'app ${isDarkMode ? "dark" : ""}'}>
      <h2>📁 CSV 업로드 및 환율 분석</h2>
      <input type="file" onChange={handleFileChange} />
      {uploadError && (
        <div className="error-box">
          {uploadError}
        </div>
      )}
      <button onClick={handleUpload}>업로드</button>
      <button onClick={handlePredict}>AI 예측</button>
      <button onClick={() => setIsDarkMode(!isDarkMode)}>
        {isDarkMode ? "🌞 라이트 모드" : "🌙 다크 모드"}
      </button>



      {csvData.length > 0 && (
        <>

          <h3>📊 데이터 미리보기</h3>
          <div className="table-wrapper">
            <table className="custom-table">
              <thead>
                <tr>
                  <th onClick={() => handleSort("date")}>날짜 {sortConfig.key === "date" && (sortConfig.direction === "asc" ? "↑" : "↓")}</th>
                  <th onClick={() => handleSort("name")}>제품명 {sortConfig.key === "name" && (sortConfig.direction === "asc" ? "↑" : "↓")}</th>
                  <th onClick={() => handleSort("quantity")}>수량 {sortConfig.key === "quantity" && (sortConfig.direction === "asc" ? "↑" : "↓")}</th>
                  <th onClick={() => handleSort("price")}>가격 {sortConfig.key === "price" && (sortConfig.direction === "asc" ? "↑" : "↓")}</th>
                  <th onClick={() => handleSort("amount")}>매출액(KRW) {sortConfig.key === "amount" && (sortConfig.direction === "asc" ? "↑" : "↓")}</th>
                </tr>
              </thead>
              <tbody>
                {(showAllRows ? sortedData : displayData).map((row, index) => (
                  <tr key={index}>
                    <td>{new Date(row.date).toISOString().substring(0, 10)}</td>
                    <td>{row.name}</td>
                    <td>{row.quantity}</td>
                    <td>{Number(row.price).toLocaleString()}</td>
                    <td>{Number(row.amount).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <button onClick={() => setShowAllRows(!showAllRows)} className="toggle-table-button">
            {showAllRows ? "간략히 보기 🔼" : "전체 보기 🔽"}
          </button>

          <div className="stats-wrapper">
            <div className="stat-card">💰 총 매출 (KRW)<br /><strong>{totalKRW.toLocaleString()} 원</strong></div>
            <div className="stat-card">📦 총 수량<br /><strong>{totalQty.toLocaleString()} 개</strong></div>
            <div className="stat-card">💳 평균 단가<br /><strong>{avgPrice.toLocaleString()} 원</strong></div>
          </div>

          <div className="chart-buttons">
            <button onClick={() => setActiveChart("bar")}>📊 막대차트</button>
            <button onClick={() => setActiveChart("line")}>📈 라인차트</button>
            <button onClick={() => setActiveChart("pie")}>🍰 파이차트</button>
          </div>

          <div className="chart-container">{renderChart()}</div>
        </>
      )}

      {aiResult && (
        <div className="ai-result">
          <h3>🤖 AI 예측 결과</h3>
          <ul>
            <li>총 매출: {aiResult.total_sales?.toLocaleString()}원</li>
            <li>평균 매출: {aiResult.avg_sales?.toLocaleString()}원</li>
            <li>최대 매출: {aiResult.max_sales?.toLocaleString()}원</li>
            <li>최소 매출: {aiResult.min_sales?.toLocaleString()}원</li>
          </ul>

          <h4>제품별 매출 요약</h4>
          <ul>
            {aiResult.product_summary &&
              Object.entries(aiResult.product_summary).map(([product, amount]) => (
                <li key={product}>{product}: {amount.toLocaleString()}원</li>
              ))}
          </ul>

          <h4>향후 7일 예측</h4>
          <ul>
            {aiResult.forecast_next_7_days &&
              Object.entries(aiResult.forecast_next_7_days).map(([date, forecast], idx) => (
                <li key={idx}>
                  {new Date(date).toISOString().substring(0, 10)}: {forecast.toLocaleString()}원</li>
              ))}
          </ul>
        </div>
      )}

      {aiResult && aiResult.chart_image && (
        <div className="ai-chart-preview">
          <h4>예측 차트 미리보기</h4>
          <img
            src={`http://localhost:5000/${aiResult.chart_image.replace(/\\/g, "/")}`}
            alt="예측 차트"
            style={{ maxWidth: "600px", marginTop: "10px" }}
          />
        </div>
      )}

      {aiResult?.outlier_image && (
        <div style={{ marginTop: "20px" }}>
          <h4>이상치 차트 미리보기</h4>
          <img src={`http://localhost:5000/${aiResult.outlier_image}`} alt="이상치 추이" style={{ maxWidth: "100%", height: "auto" }} />
        </div>
      )}

    </div>
  );
}

export default App;
